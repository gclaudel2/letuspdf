#!/bin/bash
# Construit LetUsPDF.app (Mac Apple Silicon + Intel) et l'installe dans Applications.
# Prérequis : Xcode installé (une fois lancé au moins). Usage : bash construire.sh
set -e
cd "$(dirname "$0")"
APP="build/LetUsPDF.app"
rm -rf build; mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"

echo "→ Compilation…"
swiftc -O -swift-version 5 -target arm64-apple-macos12.0 main.swift -o build/arm64 -framework Cocoa -framework WebKit
if swiftc -O -swift-version 5 -target x86_64-apple-macos12.0 main.swift -o build/x86 -framework Cocoa -framework WebKit 2>/dev/null; then
  lipo -create -output "$APP/Contents/MacOS/LetUsPDF" build/arm64 build/x86
else
  cp build/arm64 "$APP/Contents/MacOS/LetUsPDF"
fi

echo "→ Ressources…"
cp -R web "$APP/Contents/Resources/web"
cp Info.plist "$APP/Contents/Info.plist"
IS=build/AppIcon.iconset; mkdir -p "$IS"
for s in 16 32 128 256 512; do
  sips -z $s $s icon-1024.png --out "$IS/icon_${s}x${s}.png" >/dev/null
  sips -z $((s*2)) $((s*2)) icon-1024.png --out "$IS/icon_${s}x${s}@2x.png" >/dev/null
done
iconutil -c icns "$IS" -o "$APP/Contents/Resources/AppIcon.icns"

echo "→ Signature locale…"
xattr -cr "$APP"
codesign --force --deep --sign - "$APP"

echo "→ Installation dans Applications…"
rm -rf /Applications/LetUsPDF.app
cp -R "$APP" /Applications/LetUsPDF.app
xattr -cr /Applications/LetUsPDF.app
echo "Terminé : Let Us PDF est dans Applications."
open /Applications/LetUsPDF.app

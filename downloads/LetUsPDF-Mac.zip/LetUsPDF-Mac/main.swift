// Let Us PDF — appli Mac (LetUsGeek)
// Une fenêtre qui contient Let Us PDF (dossier « web » embarqué, servi par letuspdf://) + les fonctions natives du Mac :
//  • « Ouvrir avec Let Us PDF » depuis le Finder, Mail… et Fichier > Ouvrir (⌘O) ;
//  • « Enregistrer » ouvre le panneau d'enregistrement du Mac ; « Partager » ouvre le partage du Mac ;
//  • les liens externes s'ouvrent dans le navigateur, le choix de fichier de la page est natif.

import Cocoa
import WebKit
import UniformTypeIdentifiers

let appScheme = "letuspdf"
let appURL = URL(string: "\(appScheme)://app/index.html")!
let isFrench = (Locale.preferredLanguages.first ?? "fr").lowercased().hasPrefix("fr")
func tr(_ fr: String, _ en: String) -> String { isFrench ? fr : en }

// MARK: - Fichiers du site embarqués

final class AppSchemeHandler: NSObject, WKURLSchemeHandler {
    private let root = Bundle.main.resourceURL!.appendingPathComponent("web", isDirectory: true)
    private static let types: [String: String] = [
        "html": "text/html; charset=utf-8", "js": "text/javascript; charset=utf-8", "mjs": "text/javascript; charset=utf-8",
        "css": "text/css; charset=utf-8", "json": "application/json", "webmanifest": "application/manifest+json",
        "png": "image/png", "jpg": "image/jpeg", "svg": "image/svg+xml", "ico": "image/x-icon",
        "wasm": "application/wasm", "ttf": "font/ttf", "otf": "font/otf", "woff": "font/woff", "woff2": "font/woff2",
        "bcmap": "application/octet-stream", "ftl": "text/plain; charset=utf-8", "txt": "text/plain; charset=utf-8",
    ]

    func webView(_ webView: WKWebView, start urlSchemeTask: WKURLSchemeTask) {
        guard let url = urlSchemeTask.request.url else {
            urlSchemeTask.didFailWithError(URLError(.badURL)); return
        }
        let parts = url.path.split(separator: "/").map(String.init).filter { $0 != ".." && $0 != "." }
        let relative = parts.isEmpty ? "index.html" : parts.joined(separator: "/")
        let file = root.appendingPathComponent(relative)
        let found = try? Data(contentsOf: file)
        let mime = Self.types[file.pathExtension.lowercased()] ?? "application/octet-stream"
        let headers = [
            "Content-Type": mime,
            "Content-Length": String(found?.count ?? 0),
            "Access-Control-Allow-Origin": "*",
            "Cache-Control": "no-cache",
        ]
        let response = HTTPURLResponse(url: url, statusCode: found == nil ? 404 : 200, httpVersion: "HTTP/1.1", headerFields: headers)!
        urlSchemeTask.didReceive(response)
        if let data = found { urlSchemeTask.didReceive(data) }
        urlSchemeTask.didFinish()
    }

    func webView(_ webView: WKWebView, stop urlSchemeTask: WKURLSchemeTask) {}
}

// MARK: - Pont entre l'appli et la page

final class Bridge: NSObject, WKScriptMessageHandler, WKNavigationDelegate, WKUIDelegate {
    static let shared = Bridge()
    weak var web: WKWebView?
    private var pending: [(name: String, b64: String)] = []
    private var timer: Timer?

    // PDF reçu du Finder / d'Ouvrir… : remis à la page dès qu'elle est prête
    func openFile(_ url: URL) {
        let scoped = url.startAccessingSecurityScopedResource()
        defer { if scoped { url.stopAccessingSecurityScopedResource() } }
        guard let data = try? Data(contentsOf: url) else { return }
        pending.append((url.lastPathComponent, data.base64EncodedString()))
        flush()
    }

    func flush() {
        timer?.invalidate()
        guard !pending.isEmpty else { return }
        guard let web = web else { return retry() }
        web.evaluateJavaScript("typeof window.__nativeOpen === 'function'") { [weak self] result, _ in
            guard let self = self else { return }
            guard (result as? Bool) == true else { return self.retry() }
            while !self.pending.isEmpty {
                let item = self.pending.removeFirst()
                let name = (try? String(data: JSONSerialization.data(withJSONObject: [item.name], options: []), encoding: .utf8)) ?? "[\"document.pdf\"]"
                web.evaluateJavaScript("window.__nativeOpen(\(name)[0], '\(item.b64)')")
            }
        }
    }

    private func retry() {
        timer = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: false) { [weak self] _ in self?.flush() }
    }

    // Enregistrer (panneau du Mac) ou Partager (menu de partage du Mac)
    func save(name: String, b64: String, share: Bool) {
        guard let data = Data(base64Encoded: b64) else { return }
        var clean = name.replacingOccurrences(of: "/", with: "-").replacingOccurrences(of: ":", with: "-")
        if clean.isEmpty { clean = "document.pdf" }
        if share {
            let dir = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString, isDirectory: true)
            let file = dir.appendingPathComponent(clean)
            do {
                try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
                try data.write(to: file)
            } catch { return }
            if let web = web {
                let picker = NSSharingServicePicker(items: [file])
                picker.show(relativeTo: NSRect(x: web.bounds.midX, y: 40, width: 1, height: 1), of: web, preferredEdge: .minY)
            }
            return
        }
        let panel = NSSavePanel()
        panel.nameFieldStringValue = clean
        panel.canCreateDirectories = true
        panel.allowedContentTypes = [UTType.pdf]
        panel.begin { response in
            guard response == .OK, let url = panel.url else { return }
            do { try data.write(to: url) } catch {
                let a = NSAlert(); a.messageText = tr("Enregistrement impossible", "Could not save"); a.informativeText = error.localizedDescription; a.runModal()
            }
        }
    }

    // Messages de la page (window.webkit.messageHandlers.letuspdf)
    func userContentController(_ controller: WKUserContentController, didReceive message: WKScriptMessage) {
        guard let body = message.body as? [String: Any], let type = body["type"] as? String else { return }
        if (type == "save" || type == "share"), let name = body["name"] as? String, let b64 = body["b64"] as? String {
            save(name: name, b64: b64, share: type == "share")
        }
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) { flush() }

    // Let Us PDF reste dans la fenêtre, le reste part vers le navigateur / Mail
    func webView(_ webView: WKWebView, decidePolicyFor action: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = action.request.url else { return decisionHandler(.cancel) }
        let scheme = url.scheme?.lowercased() ?? ""
        if scheme == appScheme || ["about", "blob", "data"].contains(scheme) { return decisionHandler(.allow) }
        if (scheme == "http" || scheme == "https") && action.targetFrame?.isMainFrame == false { return decisionHandler(.allow) }
        NSWorkspace.shared.open(url)
        decisionHandler(.cancel)
    }

    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration,
                 for action: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        if let url = action.request.url { NSWorkspace.shared.open(url) }
        return nil
    }

    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) { webView.reload() }

    // Choix de fichier de la page (<input type=file>)
    func webView(_ webView: WKWebView, runOpenPanelWith parameters: WKOpenPanelParameters,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping ([URL]?) -> Void) {
        let panel = NSOpenPanel()
        panel.allowsMultipleSelection = parameters.allowsMultipleSelection
        panel.canChooseFiles = true
        panel.canChooseDirectories = false
        panel.begin { response in completionHandler(response == .OK ? panel.urls : nil) }
    }

    // alert(), confirm(), prompt() de la page
    func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
        let a = NSAlert(); a.messageText = message; a.addButton(withTitle: "OK"); a.runModal(); completionHandler()
    }

    func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) {
        let a = NSAlert(); a.messageText = message
        a.addButton(withTitle: "OK"); a.addButton(withTitle: tr("Annuler", "Cancel"))
        completionHandler(a.runModal() == .alertFirstButtonReturn)
    }

    func webView(_ webView: WKWebView, runJavaScriptTextInputPanelWithPrompt prompt: String, defaultText: String?,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (String?) -> Void) {
        let a = NSAlert(); a.messageText = prompt
        a.addButton(withTitle: "OK"); a.addButton(withTitle: tr("Annuler", "Cancel"))
        let field = NSTextField(frame: NSRect(x: 0, y: 0, width: 280, height: 24))
        field.stringValue = defaultText ?? ""
        a.accessoryView = field
        completionHandler(a.runModal() == .alertFirstButtonReturn ? field.stringValue : nil)
    }
}

// MARK: - Application

final class AppDelegate: NSObject, NSApplicationDelegate {
    var window: NSWindow!

    func applicationDidFinishLaunching(_ notification: Notification) {
        let config = WKWebViewConfiguration()
        config.applicationNameForUserAgent = "letuspdf-mac"
        config.userContentController.add(Bridge.shared, name: "letuspdf")
        config.setURLSchemeHandler(AppSchemeHandler(), forURLScheme: appScheme)
        let web = WKWebView(frame: .zero, configuration: config)
        web.navigationDelegate = Bridge.shared
        web.uiDelegate = Bridge.shared
        if #available(macOS 13.3, *) { web.isInspectable = true }
        Bridge.shared.web = web
        web.load(URLRequest(url: appURL))

        window = NSWindow(contentRect: NSRect(x: 0, y: 0, width: 1280, height: 860),
                          styleMask: [.titled, .closable, .miniaturizable, .resizable],
                          backing: .buffered, defer: false)
        window.title = "Let Us PDF"
        window.contentView = web
        window.minSize = NSSize(width: 520, height: 420)
        window.setFrameAutosaveName("LetUsPDFMain")
        if !window.setFrameUsingName("LetUsPDFMain") { window.center() }
        window.makeKeyAndOrderFront(nil)
        NSApp.activate(ignoringOtherApps: true)
        buildMenu()
    }

    // « Ouvrir avec Let Us PDF » depuis le Finder, Mail…
    func application(_ application: NSApplication, open urls: [URL]) {
        for u in urls { Bridge.shared.openFile(u) }
    }

    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool { true }

    @objc func openDocument(_ sender: Any?) {
        let panel = NSOpenPanel()
        panel.allowedContentTypes = [UTType.pdf]
        panel.allowsMultipleSelection = true
        if panel.runModal() == .OK { for u in panel.urls { Bridge.shared.openFile(u) } }
    }

    private func item(_ title: String, _ action: String?, _ key: String = "", _ mods: NSEvent.ModifierFlags = .command) -> NSMenuItem {
        let it = NSMenuItem(title: title, action: action.map { NSSelectorFromString($0) }, keyEquivalent: key)
        it.keyEquivalentModifierMask = mods
        return it
    }

    private func buildMenu() {
        let main = NSMenu()
        func add(_ title: String, _ items: [NSMenuItem]) {
            let holder = NSMenuItem(); main.addItem(holder)
            let m = NSMenu(title: title)
            for i in items { m.addItem(i) }
            holder.submenu = m
        }
        let sep = { NSMenuItem.separator() }
        add("Let Us PDF", [
            item(tr("À propos de Let Us PDF", "About Let Us PDF"), "orderFrontStandardAboutPanel:"), sep(),
            item(tr("Masquer Let Us PDF", "Hide Let Us PDF"), "hide:", "h"),
            item(tr("Masquer les autres", "Hide Others"), "hideOtherApplications:", "h", [.command, .option]), sep(),
            item(tr("Quitter Let Us PDF", "Quit Let Us PDF"), "terminate:", "q"),
        ])
        let open = item(tr("Ouvrir…", "Open…"), "openDocument:", "o"); open.target = self
        add(tr("Fichier", "File"), [open, sep(), item(tr("Fermer", "Close"), "performClose:", "w")])
        add(tr("Édition", "Edit"), [
            item(tr("Annuler", "Undo"), "undo:", "z"),
            item(tr("Rétablir", "Redo"), "redo:", "z", [.command, .shift]), sep(),
            item(tr("Couper", "Cut"), "cut:", "x"), item(tr("Copier", "Copy"), "copy:", "c"),
            item(tr("Coller", "Paste"), "paste:", "v"), item(tr("Tout sélectionner", "Select All"), "selectAll:", "a"),
        ])
        add(tr("Fenêtre", "Window"), [
            item(tr("Placer dans le Dock", "Minimize"), "performMiniaturize:", "m"),
            item(tr("Plein écran", "Enter Full Screen"), "toggleFullScreen:", "f", [.command, .control]),
        ])
        NSApp.mainMenu = main
    }
}

let app = NSApplication.shared
let delegate = AppDelegate()
app.delegate = delegate
app.setActivationPolicy(.regular)
app.run()
